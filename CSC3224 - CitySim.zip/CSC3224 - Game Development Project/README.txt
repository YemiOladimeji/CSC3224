INSTRUCTIONS:

1) Right-click to pull up the Tile-selection menu.
2) Drag across the map(?) to place the tiles you've selected, if you have enough funds.
3) ????
4) Experiment and have fun!