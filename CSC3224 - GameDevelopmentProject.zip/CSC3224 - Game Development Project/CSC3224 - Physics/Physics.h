#pragma once
#ifndef PHYSICS_H
#define PHYSICS_H

using namespace std;

class Physics 
{
public:

	Physics(); //Default constructor
	~Physics() {}; //Destructor

	
};

#endif //PHYSICS_H
